import os, subprocess, glob
import pandas as pd

print('Welcome to sequencing data analysis, The Pocket, designed by Dr. Gilman Siu laboratory.')

#Checking the sequencing alignment FASTA files in Pocket folder
pocket = os.chdir(str(os.getcwd())+('\\pocket'))
FASTAFileinpocket = glob.glob('*.fasta')
TotalFASTAFile = sum('.fasta' in f for f in FASTAFileinpocket)
print('The total number of sequencing FASTA files in Pocket is: ' + str(TotalFASTAFile))
FASTAfiledictionary = dict(enumerate(FASTAFileinpocket, 1)) #Setting a dictionary for the FASTA files in Pocket folder


#Submitting the FASTA files to BLAST 16SMicrobial analysis.
def BLAST_16SMicrobial():
	b = 1
	PathtoFASTAfile = os.getcwd()
	inputFASTAfilename = []
	commandline = ''
	while b > 0 and b <= max(FASTAfiledictionary, key=int):
		inputFASTAfilename = FASTAfiledictionary[b]
		FASTAto16SMicrobial_commandline = 'C:\\blast_plus\\bin\\blastn.exe -db C:\\blastdb\\16S_ribosomal_RNA -perc_identity 90 -qcov_hsp_perc 90 -outfmt 6 -num_alignments 3 -query ' + str(PathtoFASTAfile) + '\\' + str(inputFASTAfilename) + ' -out ' + str(PathtoFASTAfile) + '\\' + str(inputFASTAfilename)[:-6] + '_hit_table.csv'
		print('BLASTN command: ' + FASTAto16SMicrobial_commandline)		
		print('Input file name: ' + inputFASTAfilename)
		subprocess.run(FASTAto16SMicrobial_commandline, shell = True)
		b = b + 1

BLAST_16SMicrobial()

#Checking the sequencing alignment csv files in Pocket folder
CSVFileinpocket = glob.glob('*.csv')
TotalCSVFile = sum('.csv' in f for f in CSVFileinpocket)
print('The total number of sequencing csv files in Pocket is: ' + str(TotalCSVFile))
CSVfiledictionary = dict(enumerate(CSVFileinpocket, 1)) #Setting a dictionary for the CSV files in Pocket folder

def speciesidentification():
	c = 1
	PathtoCSVfile = os.getcwd()
	inputCSVfilename = []
	while c > 0 and c <= max(CSVfiledictionary, key=int):
		inputCSVfilename = CSVfiledictionary[c]
		pdcsv = pd.read_csv(str(inputCSVfilename), delimiter = '	', names = ["query_id", "subject_id", "%identity", "alignment_length", "mismatch", "gap_open", "query_start", "query_end", "subject_start", "subject_end", "e_value", "bit_score"])
		Query_dict = dict(enumerate(pdcsv["query_id"].unique(), 1))
		d = 1
		while d > 0 and d <= max(Query_dict, key=int):
			e = 0
			Specificquerytolist = pdcsv.index[pdcsv['query_id'] == str(Query_dict[d])].tolist()
			while e >= 0 and e <= int(len(Specificquerytolist) - 1):
				fw = open(str(inputCSVfilename)[:-4] + '_top' + str(e+1) + '_extraction.csv', 'a')
				Specificqueryquery = pdcsv.loc[Specificquerytolist[e], 'query_id']
				Specificquerysubject = pdcsv.loc[Specificquerytolist[e], 'subject_id']
				Specificqueryidentity = pdcsv.loc[Specificquerytolist[e], '%identity']
				Specificqueryalignmentlength = pdcsv.loc[Specificquerytolist[e], 'alignment_length']
				Specificquerymismatch = pdcsv.loc[Specificquerytolist[e], 'mismatch']
				Specificquerygap = pdcsv.loc[Specificquerytolist[e], 'gap_open']
				Specificqueryquerystart = pdcsv.loc[Specificquerytolist[e], 'query_start']
				Specificqueryqueryend = pdcsv.loc[Specificquerytolist[e], 'query_end']
				Specificquerysubjectstart = pdcsv.loc[Specificquerytolist[e], 'subject_start']
				Specificquerysubjectend = pdcsv.loc[Specificquerytolist[e], 'subject_end']
				Specificqueryevalue = pdcsv.loc[Specificquerytolist[e], 'e_value']
				Specificquerybitscore = pdcsv.loc[Specificquerytolist[e], 'bit_score']
				fw.write(str(Specificqueryquery) + ',' + str(Specificquerysubject) + ',' + str(Specificqueryidentity) + ',' + str(Specificqueryalignmentlength) + ',' + str(Specificquerymismatch) + ',' + str(Specificquerygap) + ',' + str(Specificqueryquerystart) + ',' + str(Specificqueryqueryend) + ',' + str(Specificquerysubjectstart) + ',' + str(Specificquerysubjectend) + ',' + str(Specificqueryevalue) + ',' + str(Specificquerybitscore) + '\n')
				fw.close()
				e = e + 1
			d = d + 1
		c = c + 1

speciesidentification()

CSVFileinpocket = glob.glob('*_extraction.csv')
TotalCSVFile = sum('_extraction.csv' in f for f in CSVFileinpocket)
print('The total number of sequencing ranked csv files in Pocket is: ' + str(TotalCSVFile))
CSVfiledictionary = dict(enumerate(CSVFileinpocket, 1)) #Setting a dictionary for the CSV files in Pocket folder

def speciesanalysis():
	f = 1
	PathtoCSVfile = os.getcwd()
	inputCSVfilename = []
	while f > 0 and f <= max(CSVfiledictionary, key=int):
		inputCSVfilename = CSVfiledictionary[f]
		pdcsv = pd.read_csv(str(inputCSVfilename), delimiter = ',', names = ["query_id", "subject_id", "%identity", "alignment_length", "mismatch", "gap_open", "query_start", "query_end", "subject_start", "subject_end", "e_value", "bit_score"])
		Species_dict = dict(enumerate(pdcsv["subject_id"].unique(), 1))
		g = 1
		fw2 = open(str(inputCSVfilename)[:-4] + '_and_analysis.csv', 'w') 
		while g > 0 and g <= max(Species_dict, key=int):
			Species_name = str(Species_dict[g])
			Species_count = pdcsv.query('subject_id == ' + '"' + str(Species_dict[g]) + '"').subject_id.count()
			fw2.write(Species_name + '|' + str(Species_count) + '\n')
			g = g + 1
		fw2.close()
		f = f + 1

speciesanalysis()


print('16SMicrobial analysis is complete. Please check the results in Pocket folder.')
